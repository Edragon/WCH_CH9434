/********************************** (C) COPYRIGHT *******************************
* File Name          : CH9434.c
* Author             : tech18
* Version            : V1.0
* Date               : 2020/05/08
* Description        : SPIת����оƬCH9434�����ӿ�
*******************************************************************************/

#include "CH9434.h"

/*
һ��оƬʱ���������˵����
1.�ⲿ����32M
2.�ڲ�ʱ��Ƶ�ʣ�32M
3.������Ƶϵ����15���̶���
4.оƬ�������ʱ��Ƶ�ʲ�����40M
5.���ڻ�׼ʱ��Ϊ����������Ƶ��32MHz  ������Ƶ��32MHz*15/��Ƶϵ��

�����Ƽ����������ʵļ��㷽ʽ
1.32M -> ���ڻ�׼ʱ�Ӽ��㲨���ʣ�32M/8/������
2.32*15/13=36.923M -> ���ڻ�׼ʱ�Ӽ��㲨���ʣ�36.923M/8/������ ���粨���ʣ�921600��

���������洢����
1.osc_xt_frequency����¼�ⲿ����Ƶ�ʣ���ʹ���ⲿ����ʱ��¼������CH9434OscXtFreqSet�޸�
2.sys_frequency���������õ�ʱ��ģʽ���ó���CH9434���ڻ�׼ʱ�ӣ����ں�����㲨����
3.lower_power_reg����¼CH9434�͹���״̬
4.ch9434_gpio_x_val��CH9434ͨ��GPIO�������ƽֵ����λ���壬�������ŵ�ƽ������CH9434GPIOPinOut
*/

//�����ⲿ����Ƶ��
u32_t osc_xt_frequency = 32000000;

//���嵱ǰ���ڻ�׼ʱ��Ƶ��
u32_t sys_frequency = 32000000;  //оƬĬ��Ϊ�ڲ�32M

//˯��ģʽ
u8_t  lower_power_reg = 0;

//GPIO�������ƽֵ ��24��GPIO
u32_t ch9434_gpio_x_val = 0;

/*******************************************************************************
* Function Name  : CH9434OscXtFreqSet
* Description    : �ⲿ����Ƶ�ʼ�¼
* Input          : x_freq����ǰоƬ���ӵľ���Ƶ��
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434OscXtFreqSet(u32_t x_freq)
{
	osc_xt_frequency = x_freq;
}

/*******************************************************************************
* Function Name  : CH9434InitClkMode
* Description    : CH9434оƬʱ��ģʽ����
* Input          : xt_en���ⲿ����ʹ��
                   freq_mul_en����Ƶ����ʹ��
                   div_num����Ƶϵ��
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434InitClkMode(u8_t xt_en,u8_t freq_mul_en,u8_t div_num)
{
	u8_t  clk_ctrl_reg;
	u16_t i;
	
	clk_ctrl_reg = 0;
	if(freq_mul_en) clk_ctrl_reg |= (1<<7);
	if(xt_en) clk_ctrl_reg |= (1<<6);
	clk_ctrl_reg |= (div_num&0x1f);
	
	/* ���㵱ǰ�Ĵ��ڻ�׼ʱ�� */
	//sys_frequency
	switch(clk_ctrl_reg&0xc0)
	{
		case 0x00: //�ڲ�32M�ṩʱ��
			sys_frequency = 32000000;
			break;
		case 0x40: //�ⲿ�����ṩʱ��
			if((osc_xt_frequency>36000000)||(osc_xt_frequency<24000000)) //ʱ�Ӵ���
			{
				return;
			}
			sys_frequency = osc_xt_frequency;
			break;
		case 0x80: //ʹ���ڲ�32M����������Ƶ
			sys_frequency = 480000000/(div_num&0x1f);
			if(sys_frequency>40000000) //ʱ�Ӵ���
			{
				sys_frequency = 32000000;
				return;
			}
			break;
		case 0xc0: //ʹ���ⲿ���񣬲�������Ƶ
			if((osc_xt_frequency>36000000)||(osc_xt_frequency<24000000)) //ʱ�Ӵ���
			{
				return;
			}
			sys_frequency = osc_xt_frequency*15/(div_num&0x1f);
			if(sys_frequency>40000000) //ʱ�Ӵ���
			{
				sys_frequency = 32000000;
				return;
			}
			break;
	}
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_CLK_CTRL_CFG_ADD);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(clk_ctrl_reg);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	for(i=0; i<50000; i++) CH9434_US_DELAY();  //�л�ʱ����Ҫ��ʱ
}

/*******************************************************************************
* Function Name  : CH9434UARTxParaSet
* Description    : ���ڲ�������
* Input          : uart_idx�����ں�
                   bps�����ڵĲ�����
                   data_bits������λ
                   stop_bits��ֹͣλ
                   veri_bits��У��λ
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxParaSet(u8_t uart_idx,u32_t bps,u8_t data_bits,u8_t stop_bits,u8_t veri_bits)
{
	u8_t  uart_reg_dll;
	u8_t  uart_reg_dlm;
	u32_t x;
	u8_t  uart_reg_lcr;
	
	x = 10 * sys_frequency / 8 / bps;
	x = ( x + 5 ) / 10;  	
	
	uart_reg_dll = x&0xff;
	uart_reg_dlm = (x>>8)&0xff;
	
	//DLAB��λ ����LCR�Ĵ���
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_LCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_lcr = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	uart_reg_lcr |= CH9434_UARTx_BIT_DLAB;
	//����λ
	uart_reg_lcr &= ~0x03;
	switch(data_bits)
	{
		case CH9434_UART_5_BITS_PER_CHAR:
			break;
		case CH9434_UART_6_BITS_PER_CHAR:
			uart_reg_lcr |= 0x01;
			break;
		case CH9434_UART_7_BITS_PER_CHAR:
			uart_reg_lcr |= 0x02;
			break;
		case CH9434_UART_8_BITS_PER_CHAR:
			uart_reg_lcr |= 0x03;
			break;
		default:
			uart_reg_lcr |= 0x03;
			break;	
	}
	//ֹͣλ
	uart_reg_lcr &= ~(1<<2);
	if(stop_bits == CH9434_UART_TWO_STOP_BITS)
	{
		uart_reg_lcr |= (1<<2);
	}
	//У��λ
	uart_reg_lcr &= ~(1<<3);
	uart_reg_lcr &= ~(3<<4);
	switch(veri_bits)
	{
		case CH9434_UART_NO_PARITY:
			break;
		case CH9434_UART_ODD_PARITY:
			uart_reg_lcr |= (1<<3);
			break;
		case CH9434_UART_EVEN_PARITY:
			uart_reg_lcr |= (1<<3);
			uart_reg_lcr |= (1<<4);
			break;
		case CH9434_UART_MARK_PARITY:
			uart_reg_lcr |= (1<<3);
			uart_reg_lcr |= (2<<4);
			break;
		case CH9434_UART_SPACE_PARITY:
			uart_reg_lcr |= (1<<3);
			uart_reg_lcr |= (3<<4);
			break;
		default:
			break;	
	}

	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_LCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_lcr);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	//����DLL DLM
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_DLL_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_dll);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_DLM_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_dlm);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	//DLAB��0
	uart_reg_lcr &= ~CH9434_UARTx_BIT_DLAB;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_LCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_lcr);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434UARTxFIFOSet
* Description    : ����FIFO����
* Input          : uart_idx�����ں�
                   fifo_en��FIFO����ʹ��
                   fifo_level��FIFO�����ȼ�
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxFIFOSet(u8_t uart_idx,u8_t fifo_en,u8_t fifo_level)
{
	u8_t  uart_reg_fcr;
	
	uart_reg_fcr = 0;
	if(fifo_en)
	{
		uart_reg_fcr |= 0x01;
		uart_reg_fcr |= fifo_level<<6;
	}
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_FCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_fcr);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434UARTxIrqSet
* Description    : �����ж�����
* Input          : uart_idx�����ں�
                   modem��modem�ź��ж�
                   line����·״̬�ж�
                   tx�������ж�
                   rx�������ж�
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxIrqSet(u8_t uart_idx,u8_t modem,u8_t line,u8_t tx,u8_t rx)
{
	u8_t  uart_reg_ier;
	
	uart_reg_ier = 0;
	if(modem) uart_reg_ier |= (1<<3);
	if(line)	uart_reg_ier |= (1<<2);
	if(tx)	  uart_reg_ier |= (1<<1);
	if(rx)	  uart_reg_ier |= (1<<0);
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_IER_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_ier);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/* ���ع��ܺ��������� */
/*******************************************************************************
* Function Name  : CH9434UARTxFlowSet
* Description    : ��������
* Input          : uart_idx�����ں�
                   flow_en������ʹ��
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxFlowSet(u8_t uart_idx,u8_t flow_en)
{
	u8_t  uart_reg_mcr;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_MCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_mcr = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
	
	uart_reg_mcr &=~(1<<5);
	if(flow_en) uart_reg_mcr |= (1<<5);
		
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_MCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_mcr);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
}

/*******************************************************************************
* Function Name  : CH9434UARTxIrqOpen
* Description    : �����жϴ�������
* Input          : uart_idx�����ں�
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxIrqOpen(u8_t uart_idx)
{
	u8_t  uart_reg_mcr;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_MCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_mcr = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
	
	uart_reg_mcr |= (1<<3);
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_MCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_mcr);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434UARTxRtsDtrPin
* Description    : ���ô���RTS��DTR����
* Input          : uart_idx�����ں�
                   rts_val��RTS���ŵ�ƽ״̬
                   dtr_val��DTR���ŵ�ƽ״̬
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxRtsDtrPin(u8_t uart_idx,u8_t rts_val,u8_t dtr_val)
{
	u8_t  uart_reg_mcr;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_MCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_mcr = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
	
	if(rts_val) uart_reg_mcr |= (1<<1);
	else        uart_reg_mcr &= ~(1<<1);
	if(dtr_val) uart_reg_mcr |= (1<<0);
	else        uart_reg_mcr &= ~(1<<0);
		
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_MCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_reg_mcr);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434UARTxWriteSRC
* Description    : SRC�Ĵ���д����
* Input          : uart_idx�����ں�
                   src_val��SRC�Ĵ���ֵ
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxWriteSRC(u8_t uart_idx,u8_t src_val)
{
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_UARTx_SCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(src_val);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434UARTxReadSRC
* Description    : SRC�Ĵ���������
* Input          : uart_idx�����ں�
* Output         : None
* Return         : SRC�Ĵ���ֵ
*******************************************************************************/
u8_t CH9434UARTxReadSRC(u8_t uart_idx)
{
	u8_t  uart_reg_src = 0;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_SCR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_src = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
	
	return uart_reg_src;
}

/*******************************************************************************
* Function Name  : CH9434UARTxReadIIR
* Description    : �����ж����ѯ
* Input          : uart_idx�����ں�
* Output         : None
* Return         : IIR�Ĵ���ֵ
*******************************************************************************/
u8_t CH9434UARTxReadIIR(u8_t uart_idx)
{
	u8_t  uart_reg_iir = 0;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_IIR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_iir = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	return uart_reg_iir;
}

/*******************************************************************************
* Function Name  : CH9434UARTxReadLSR
* Description    : ����LSR�Ĵ�����ȡ
* Input          : uart_idx�����ں�
* Output         : None
* Return         : LSR�Ĵ���ֵ
*******************************************************************************/
u8_t CH9434UARTxReadLSR(u8_t uart_idx)
{
	u8_t  uart_reg_lsr = 0;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_LSR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_lsr = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	return uart_reg_lsr;
}

/*******************************************************************************
* Function Name  : CH9434UARTxReadMSR
* Description    : ����MSR�Ĵ�����ȡ
* Input          : uart_idx�����ں�
* Output         : None
* Return         : MSR�Ĵ���ֵ
*******************************************************************************/
u8_t CH9434UARTxReadMSR(u8_t uart_idx)
{
	u8_t  uart_reg_msr = 0;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_UARTx_MSR_ADD+0x10*uart_idx);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_reg_msr = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	return uart_reg_msr;
}

/* �����շ����� */
/*******************************************************************************
* Function Name  : CH9434UARTxGetRxFIFOLen
* Description    : ��ȡ���ڽ������ݳ���
* Input          : uart_idx�����ں�
* Output         : None
* Return         : ���ڽ���FIFO�Ĵ�С
*******************************************************************************/
u16_t CH9434UARTxGetRxFIFOLen(u8_t uart_idx)
{
	u8_t  uart_fifo_ctrl = 0;
	u8_t  uart_fifo_cnt_l;
	u8_t  uart_fifo_cnt_h;
	u16_t uart_fifo_cnt = 0;
	
	uart_fifo_ctrl |= uart_idx;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_FIFO_CTRL_ADD);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_fifo_ctrl);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	//CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_FIFO_CTRL_L_ADD);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	//CH9434_US_DELAY();
	uart_fifo_cnt_l = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_FIFO_CTRL_H_ADD);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	//CH9434_US_DELAY();
	uart_fifo_cnt_h = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_SPI_SCS_OP(CH9434_ENABLE);

	uart_fifo_cnt = uart_fifo_cnt_h;
	uart_fifo_cnt = (uart_fifo_cnt<<8) | uart_fifo_cnt_l;

	return uart_fifo_cnt;
}

/*******************************************************************************
* Function Name  : CH9434UARTxGetRxFIFOData
* Description    : ��ȡ���ڽ�������
* Input          : uart_idx�����ں�
                   p_data�����ݴ洢ָ��
                   read_len����ȡ�����ݳ���
* Output         : None
* Return         : ��
*******************************************************************************/
u8_t CH9434UARTxGetRxFIFOData(u8_t uart_idx,u8_t *p_data,u16_t read_len)
{
	u16_t i;
	u8_t  *p_sv_data;
	u8_t  uart_reg_add;
	
	uart_reg_add = CH9434_REG_OP_READ|CH9434_UARTx_RBR_ADD+0x10*uart_idx;
	p_sv_data = p_data;
	for(i=0; i<read_len; i++)
	{
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(uart_reg_add);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		*p_sv_data++ = CH9434_SPI_WRITE_BYTE(0xff);
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
	}
	
	return 0;
}

/*******************************************************************************
* Function Name  : CH9434UARTxGetTxFIFOLen
* Description    : ��ȡ���ڷ���FIFO����
* Input          : uart_idx�����ں�
* Output         : None
* Return         : ��ǰ���ڵĽ������ݳ���
*******************************************************************************/
u16_t CH9434UARTxGetTxFIFOLen(u8_t uart_idx)
{
	u8_t  uart_fifo_ctrl = 0;
	u8_t  uart_fifo_cnt_l;
	u8_t  uart_fifo_cnt_h;
	u16_t uart_fifo_cnt = 0;
	
	uart_fifo_ctrl |= CH9434_FIFO_CTRL_TR;
	uart_fifo_ctrl |= uart_idx;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_FIFO_CTRL_ADD);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(uart_fifo_ctrl);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
		
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_FIFO_CTRL_L_ADD);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_fifo_cnt_l = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_FIFO_CTRL_H_ADD);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	uart_fifo_cnt_h = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_SPI_SCS_OP(CH9434_ENABLE);

	uart_fifo_cnt = uart_fifo_cnt_h;
	uart_fifo_cnt = (uart_fifo_cnt<<8) | uart_fifo_cnt_l;

	return uart_fifo_cnt;
}

/*******************************************************************************
* Function Name  : CH9434UARTxSetTxFIFOData
* Description    : �������뷢������
* Input          : uart_idx�����ں�
                   p_data����������ָ��
                   send_len�����͵����ݳ���
* Output         : None
* Return         : ��
*******************************************************************************/
u8_t CH9434UARTxSetTxFIFOData(u8_t uart_idx,u8_t *p_data,u16_t send_len)
{
	u16_t i;
	u8_t  *p_sv_data;
	u8_t  uart_reg_add;
	
	uart_reg_add = CH9434_REG_OP_WRITE|CH9434_UARTx_RBR_ADD+0x10*uart_idx;
	p_sv_data = p_data;
	for(i=0; i<send_len; i++)
	{
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(uart_reg_add);
		CH9434_US_DELAY();
		CH9434_SPI_WRITE_BYTE(*p_sv_data++);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
	}
	
	return 0;
}

/*******************************************************************************
* Function Name  : CH9434UARTxTnowSet
* Description    : ����485�л���������
* Input          : uart_idx�����ں�
                   tnow_en������tnowʹ��״̬
                   polar�����Է�������
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434UARTxTnowSet(u8_t uart_idx,u8_t tnow_en,u8_t polar)
{
	u8_t  tnow_ctrl_reg;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_TNOW_CTRL_CFG_ADD);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	tnow_ctrl_reg = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
	
	if(tnow_en) tnow_ctrl_reg |= (1<<uart_idx);
	else        tnow_ctrl_reg &=~(1<<uart_idx);
		
	if(polar) tnow_ctrl_reg |= (1<<(uart_idx+4));
	else      tnow_ctrl_reg &=~(1<<(uart_idx+4));
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_TNOW_CTRL_CFG_ADD);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(tnow_ctrl_reg);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434LowerPowerModeSet
* Description    : CH9434оƬ�͹�������
* Input          : mode���͹���ģʽ
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434LowerPowerModeSet(u8_t mode)
{
	lower_power_reg = mode;
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_SLEEP_MOD_CFG_ADD);
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(lower_power_reg);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434WakeUp
* Description    : CH9434���Ѳ������ӵ͹���ģʽ�л��ѣ�Ҳ�ɲ���SPI���л���
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434WakeUp(void)
{
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434GPIOFuncSet
* Description    : GPIO��������
* Input          : gpio_idx��GPIO���
                   en��ʹ��״̬
                   dir��GPIO����
                   pu����������
                   pd����������
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434GPIOFuncSet(u8_t gpio_idx,u8_t en,u8_t dir,u8_t pu,u8_t pd)
{
	u8_t gpio_func_reg;   //  GPIO_FUNC
	u8_t gpio_dir_reg;
	u8_t gpio_pu_reg;
	u8_t gpio_pd_reg;
	
	if(en)
	{
		//GPIOʹ��
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_GPIO_FUNC_EN_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		gpio_func_reg = CH9434_SPI_WRITE_BYTE(0xff);
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		gpio_func_reg |= (1<<(gpio_idx%8));
		
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_GPIO_FUNC_EN_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_SPI_WRITE_BYTE(gpio_func_reg);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		//GPIO��������
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_GPIO_DIR_MOD_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		gpio_dir_reg = CH9434_SPI_WRITE_BYTE(0xff);
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		if(dir) gpio_dir_reg |= (1<<(gpio_idx%8));
		else    gpio_dir_reg &=~(1<<(gpio_idx%8));
		
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_GPIO_DIR_MOD_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_SPI_WRITE_BYTE(gpio_dir_reg);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		//��������
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_GPIO_PU_MOD_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		gpio_pu_reg = CH9434_SPI_WRITE_BYTE(0xff);
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		if(pu) gpio_pu_reg |= (1<<(gpio_idx%8));
		else   gpio_pu_reg &=~(1<<(gpio_idx%8));
		
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_GPIO_PU_MOD_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_SPI_WRITE_BYTE(gpio_pu_reg);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		//��������
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_GPIO_PD_MOD_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		gpio_pd_reg = CH9434_SPI_WRITE_BYTE(0xff);
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		if(pd) gpio_pd_reg |= (1<<(gpio_idx%8));
		else   gpio_pd_reg &=~(1<<(gpio_idx%8));
		
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_GPIO_PD_MOD_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_SPI_WRITE_BYTE(gpio_pd_reg);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
	}
	else
	{
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_GPIO_FUNC_EN_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		gpio_func_reg = CH9434_SPI_WRITE_BYTE(0xff);
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
		
		gpio_func_reg &= ~(1<<(gpio_idx%8));
		
		CH9434_SPI_SCS_OP(CH9434_DISABLE);
		CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_GPIO_FUNC_EN_0+(gpio_idx/8));
		CH9434_US_DELAY();
		CH9434_SPI_WRITE_BYTE(gpio_func_reg);
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_US_DELAY();
		CH9434_SPI_SCS_OP(CH9434_ENABLE);
	}
}

/*******************************************************************************
* Function Name  : CH9434GPIOPinOut
* Description    : GPIO�����ƽ����
* Input          : gpio_idx��GPIO���
                   out_val�������ƽ����
* Output         : None
* Return         : None
*******************************************************************************/
void CH9434GPIOPinOut(u8_t gpio_idx,u8_t out_val)
{
	u8_t pin_val_reg;
	
	if(out_val) ch9434_gpio_x_val |= (1<<gpio_idx);
	else        ch9434_gpio_x_val &= ~(1<<gpio_idx);
	
	pin_val_reg = (u8_t)(ch9434_gpio_x_val>>((gpio_idx/8)*8));
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_WRITE|CH9434_GPIO_PIN_VAL_0+(gpio_idx/8));
	CH9434_US_DELAY();
	CH9434_SPI_WRITE_BYTE(pin_val_reg);
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_SPI_SCS_OP(CH9434_ENABLE);
}

/*******************************************************************************
* Function Name  : CH9434GPIOPinVal
* Description    : GPIO��ƽ��ȡ
* Input          : gpio_idx��GPIO���
* Output         : None
* Return         : ��ƽ״̬��1���ߵ�ƽ 0���͵�ƽ
*******************************************************************************/
u8_t CH9434GPIOPinVal(u8_t gpio_idx)
{
	u8_t pin_val_reg;
	
	CH9434_SPI_SCS_OP(CH9434_DISABLE);
	CH9434_SPI_WRITE_BYTE(CH9434_REG_OP_READ|CH9434_GPIO_PIN_VAL_0+(gpio_idx/8));
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	CH9434_US_DELAY();
	pin_val_reg = CH9434_SPI_WRITE_BYTE(0xff);
	CH9434_SPI_SCS_OP(CH9434_ENABLE);	
	
	if(pin_val_reg & (1<<(gpio_idx%8))) return 1;
	else                                return 0;
}
