Note: the latest version can be obtained from the following link: http://www.wch.cn/bbs/thread-69666-1.html

1. this contains ch9434 driver and uart application

2. enter "driver" directory to compile the ch9434 driver, please read README.md first

3. enter "demo" directory to compile the uart application, you can use gcc or Cross-compile with cross-gcc